//
//  NetworkManager.swift
//  GoRestTest
//
//  Created by Rodrigo Hernández Gómez on 17/12/2020.
//  Copyright © 2020 Rodrigo Hernández Gómez. All rights reserved.
//

import Foundation
class Post: Codable {

let userId: Int
let title: String
let body: String

init(title: String, body: String, userId: Int) {
    self.title = title
    self.body = body
    self.userId = userId
    }
    
}
class Network {
    
    static var shared: Network = Network()
    
}


protocol GoRestAPI {
    
    func getUsers()
    
    func postUser()
    
    func patchUser()
    
    func putUser()
    
    func deleteUser()
    
}


extension Network: GoRestAPI {
    
    static let ACCESS_TOKEN = "b1a8abf27f637a0240c6d67fb1e69011f9b5fee53f0a95f941c33cd01b841fdf"
    
    //TODO
    func getUsers() {
    let headers = ["content-type": "application/json; charset=UTF-8"]

           let newPost = Post(title: "Nuevo Post", body: "vete a hacer la compra", userId: 3)
           
           let encoder = JSONEncoder.init()
           
           var postData: Data!
           
           do {
               let postSerilized = try! encoder.encode(newPost)
               postData = try! Data(encoder.encode(newPost))
           }catch{
               print(error)
           }

           let request = NSMutableURLRequest(url: NSURL(string: "https://gorest.co.in/public-api/posts")! as URL,
                                                   cachePolicy: .useProtocolCachePolicy,
                                               timeoutInterval: 10.0)
           request.httpMethod = "GET"
           request.allHTTPHeaderFields = headers
           request.httpBody = postData as Data

           let session = URLSession.shared
           let dataTask = session.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
             if (error != nil) {
               print(error)
             } else {
               let httpResponse = response as? HTTPURLResponse
               print(httpResponse)
             }
           })

           dataTask.resume()
    
    }
    //TODO
    func postUser() {
        // Prepare URL
        let url = URL(string: "https://gorest.co.in/public-api/users")
        guard let requestUrl = url else { fatalError() }
        // Prepare URL Request Object
        var request = URLRequest(url: requestUrl)
        request.httpMethod = "POST"
         
        // HTTP Request Parameters which will be sent in HTTP Request Body
        let postString = "userId=300&title=My urgent task&completed=false";
        // Set HTTP Request Body
        request.httpBody = postString.data(using: String.Encoding.utf8);
        // Perform HTTP Request
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
                
                // Check for Error
                if let error = error {
                    print((error))
                    return
                }
         
                // Convert HTTP Response Data to a String
                if let data = data, let dataString = String(data: data, encoding: .utf8) {
                    print((dataString))
                }
        }
        task.resume()
           
    }
    
    //TODO
    func patchUser() {
        
    }
    
    //TODO
    func putUser() {
        
    }
    
    //TODO
    func deleteUser() {
        
    }
    
}

